//
//  NotificationMacro.h
//  Novel
//
//  Created by xth on 2018/1/11.
//  Copyright © 2018年 th. All rights reserved.
//

#ifndef NotificationMacro_h
#define NotificationMacro_h

//改变阅读页面背景颜色的通知
#define kNotificationWithChangeBg @"kNotificationWithChangeBg"

//白天和黑夜模式的切换通知
#define kNotificationDayAndNightBg @"kNotificationDayAndNightBg"

#endif /* NotificationMacro_h */
