//
//  XXDirectoryCell.h
//  Novel
//
//  Created by app on 2018/1/19.
//  Copyright © 2018年 th. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface XXDirectoryCell : BaseTableViewCell

- (void)configTitle:(NSString *)title indexPath:(NSIndexPath *)indexPath;

@end
