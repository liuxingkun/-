//
//  BatteryView.h
//  Novel
//
//  Created by th on 2017/3/27.
//  Copyright © 2017年 th. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BatteryView : UIView

@property (strong, nonatomic) UIColor *fillColor;

@end
