//
//  XXSummaryApi.m
//  Novel
//
//  Created by app on 2018/1/20.
//  Copyright © 2018年 th. All rights reserved.
//

#import "XXSummaryApi.h"

@implementation XXSummaryApi


- (id)jsonValidator {
    return [NSArray class];
}

@end
