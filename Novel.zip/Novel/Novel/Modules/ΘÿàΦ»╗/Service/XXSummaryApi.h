//
//  XXSummaryApi.h
//  Novel
//
//  Created by app on 2018/1/20.
//  Copyright © 2018年 th. All rights reserved.
//

#import "BaseRequestApi.h"

@interface XXSummaryApi : BaseRequestApi

@end
