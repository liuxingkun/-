//
//  XXChaptersApi.m
//  Novel
//
//  Created by app on 2018/1/20.
//  Copyright © 2018年 th. All rights reserved.
//

#import "XXChaptersApi.h"

@implementation XXChaptersApi

- (id)jsonValidator {
    return [NSObject class];
}

@end
