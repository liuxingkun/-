//
//  XXSummaryCell.h
//  Novel
//
//  Created by app on 2018/1/25.
//  Copyright © 2018年 th. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface XXSummaryCell : BaseTableViewCell

@end
