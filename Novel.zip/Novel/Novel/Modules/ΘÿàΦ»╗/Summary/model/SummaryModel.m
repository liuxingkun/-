//
//  SummaryModel.m
//  Novel
//
//  Created by th on 2017/3/9.
//  Copyright © 2017年 th. All rights reserved.
//

#import "SummaryModel.h"

@implementation SummaryModel

@end
