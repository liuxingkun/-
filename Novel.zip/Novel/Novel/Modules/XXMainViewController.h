//
//  XXMainViewController.h
//  Novel
//
//  Created by xth on 2018/1/15.
//  Copyright © 2018年 th. All rights reserved.
//

#import <WMPageController/WMPageController.h>

@interface XXMainViewController : WMPageController

@end
