
//
//  XXBookDetailApi.m
//  Novel
//
//  Created by xth on 2018/1/15.
//  Copyright © 2018年 th. All rights reserved.
//

#import "XXBookDetailApi.h"

@implementation XXBookDetailApi


- (id)jsonValidator {
    return [NSObject class];
}

@end
