//
//  xxUpdateChapterApi.m
//  Novel
//
//  Created by xth on 2018/1/11.
//  Copyright © 2018年 th. All rights reserved.
//

#import "XXUpdateChapterApi.h"

@implementation XXUpdateChapterApi

- (id)jsonValidator {
    return [NSArray class];
}

@end
