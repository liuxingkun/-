//
//  xxBookShelfVC.h
//  Novel
//
//  Created by xth on 2018/1/10.
//  Copyright © 2018年 th. All rights reserved.
//

#import "BaseTableViewController.h"

@interface XXBookShelfVC : BaseTableViewController

@end
