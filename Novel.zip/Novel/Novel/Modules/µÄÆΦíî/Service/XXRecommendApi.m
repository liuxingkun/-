//
//  XXRecommendApi.m
//  Novel
//
//  Created by xth on 2018/1/14.
//  Copyright © 2018年 th. All rights reserved.
//

#import "XXRecommendApi.h"

@implementation XXRecommendApi

- (id)jsonValidator {
    return @{@"ok": [NSNumber class]};
}

@end
