//
//  XXRankingCell.h
//  Novel
//
//  Created by xth on 2018/1/13.
//  Copyright © 2018年 th. All rights reserved.
//

#import "BaseTableViewCell.h"

@interface XXRankingCell : BaseTableViewCell

@end
