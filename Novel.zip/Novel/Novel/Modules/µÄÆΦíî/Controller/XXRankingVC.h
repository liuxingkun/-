//
//  XXRankingVC.h
//  Novel
//
//  Created by xth on 2018/1/13.
//  Copyright © 2018年 th. All rights reserved.
//

#import "BaseTableViewController.h"

typedef NS_ENUM(int, kRankingOperation) {
    kRankingOperation_insert = 300,
    kRankingOperation_delete
};


@interface XXRankingVC : BaseTableViewController

@end
