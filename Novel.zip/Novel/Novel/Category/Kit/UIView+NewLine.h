//
//  UIView+NewLine.h
//  Novel
//
//  Created by xth on 2018/1/13.
//  Copyright © 2018年 th. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (NewLine)


/**
 new一个线条颜色的对象

 @return <#return value description#>
 */
+ (UIView *)newLine;

@end
