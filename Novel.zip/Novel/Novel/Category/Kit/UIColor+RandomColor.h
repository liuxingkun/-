//
//  UIColor+RandomColor.h
//  Novel
//
//  Created by th on 2017/2/12.
//  Copyright © 2017年 th. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (RandomColor)

/**
 随机颜色
 */

+ (UIColor *)randomColor;

@end
