//
//  UIViewController+Nav.h
//  Novel
//
//  Created by app on 2018/1/17.
//  Copyright © 2018年 th. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Nav)

- (void)addBackItem;

- (void)go2Back;

@end
