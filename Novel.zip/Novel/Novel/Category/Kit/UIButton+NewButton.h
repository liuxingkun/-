//
//  UIButton+NewButton.h
//  Novel
//
//  Created by xth on 2018/1/15.
//  Copyright © 2018年 th. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (NewButton)

+ (UIButton *)newButtonTitle:(NSString *)title font:(CGFloat)fontSize normarlColor:(UIColor *)normalColor;

@end
